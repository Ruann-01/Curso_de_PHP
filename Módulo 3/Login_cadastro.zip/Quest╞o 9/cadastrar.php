<html>
    <head>
        <title></title>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    </head>
    <body>
        <div>
            Cadastro de usuário
        </div>
        <form action="controle_cadastro.php" method="POST">
            <label>Login</label>
            <input type="text" name="login" value="" /><br />
            <label>Senha</label>
            <input type="password" name="senha" value="" /><br />
            <button class="btn btn-primary">Cadastrar</button>
        </form>
    </body>
</html>