<html>
    <head>
        <title></title>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    </head>
    <body>
        <div>
            Login
        </div>
        <form action="controle.php" method="POST">
            <input type="text" name="login" value="" />
            <input type="password" name="senha" value="" />
            <button class="btn btn-primary">Login</button>
            <a href="cadastrar.php">Sem cadastro?</a>
        </form>
    </body>
</html>